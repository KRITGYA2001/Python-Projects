# Face-and-Eye-Detection-
Face and Eye Detection Program Using Python Modules (cv2)


Download All Three files and paste them in one folder.
Open Face_and_Eye_Detection.py file into your editor/Compiler and run.
